let tamanhoSenha = 12;
numeroSenha.textContent = tamanhoSenha;
const letrasMaiusculas = 'ABCDEFGHIJKLMNOPQRSTUVXWYZ';
const letrasMinusculas = 'abcdefghijklmnopqrstuvxwyz'; 
const numeros = '0123456789';
const simbolos = '!@%*ç?#-_;,.></{}()';
const numeroSenha = document.querySelector('.parametro-senha__texto')



